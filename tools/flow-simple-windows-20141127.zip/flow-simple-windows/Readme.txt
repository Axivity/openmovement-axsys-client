A simplified version of "flow" (Facebook, github facebook/flow), 
  commit 33155d2065a021851151a8b96e7af7a8c2ab90de, to run on Windows.

Rename "flow32.exe" or "flow64.exe" to "flow.exe" depending on your system.

It was compiled using ocpwin (http://www.typerex.org/ocpwin.html),
after removing most of the C stuff.

Fow now, for any issue, use:
https://github.com/facebook/flow/issues/6

-----------------
The OCamlPro team.
